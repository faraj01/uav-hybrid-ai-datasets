# Real-Time Adaptive Modulation for Drones via AI-Driven Hybrid Synergy - Datasets

This repository contains the datasets used in the paper *"Real-Time Adaptive Modulation for Drones via AI-Driven Hybrid Synergy"*.

## Dataset Structure

```
datasets/
├── synthetic/
│   └── snr_training_data.csv
├── simulation/
│   └── simulation_data.csv
├── real_world/
│   └── snr_traces.csv
├── hil/
│   └── hil_results.csv
├── field_test/
│   └── field_test_results.csv
```

## Citation

Hamzah Faraj, "Real-Time Adaptive Modulation for Drones via AI-Driven Hybrid Synergy", 2025.
